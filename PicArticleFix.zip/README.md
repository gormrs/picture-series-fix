# picture-series-fix

Chrome extensions that changes picture article from NRK (currently) to simple normal articles

tested on : https://www.nrk.no/norge/ibsens-skjulte-skattekammer-1.16329018
https://www.nrk.no/osloogviken/sunshine-effekten-1.16329137

Icon: Yllnor13

To install:

1. Pull the repo onto computer

2. Goto chrome://extensions/

3. Activate developer mode 

4. Press load unpacked and choose the folder where the files are

5. Now you can use it as any other extension in Chrome

6. To use it, go to a picture article and press the extension icon
